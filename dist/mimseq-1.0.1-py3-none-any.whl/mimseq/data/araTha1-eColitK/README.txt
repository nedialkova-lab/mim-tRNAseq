# Arabidopsis TAIR10 reference from GtRNAdb
# Plastid reference sequences from PtRNAdb - http://14.139.61.8/PtRNAdb/index.php
# convertPtRNAdbSearch.py to create araTha1-plastidtRNAs.fa in correct format as in other species mitotRNAs files