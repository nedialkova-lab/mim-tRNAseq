# Arabidopsis TAIR10 reference from GtRNAdb
# Plastid reference sequences from PtRNAdb - http://14.139.61.8/PtRNAdb/index.php
# convertPtRNAdbSearch.py to create araTha1-plastidtRNAs.fa in correct format as in other species mitotRNAs files

###### NB ######
Some tRNAs incorrectly named based on duplicates sequence

Arabidopsis_thaliana_tRNA-Arg-TCT-4-1 shares sequence with Arabidopsis_thaliana_tRNA-Arg-TCT-3-1. Renamed to Arabidopsis_thaliana_tRNA-Arg-TCT-3-2