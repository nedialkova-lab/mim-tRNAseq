###### NB ######
Some tRNAs incorrectly named!
Rattus_norvegicus_tRNA-Gln-CTG-4-1 shares exact sequence with other CTG-2 genes. Rename to Rattus_norvegicus_tRNA-Gln-CTG-2-3.

Rattus_norvegicus_tRNA-Tyr-GTA-5-1 has same mature tRNA sequence as Rattus_norvegicus_tRNA-Tyr-GTA-6-1 after intron removal. Rename Rattus_norvegicus_tRNA-Tyr-GTA-6-1 to Rattus_norvegicus_tRNA-Tyr-GTA-5-2

Rattus_norvegicus_tRNA-Tyr-GTA-3-1 has same mature tRNA sequence as Rattus_norvegicus_tRNA-Tyr-GTA-4-1 after intron removal. Rename Rattus_norvegicus_tRNA-Tyr-GTA-4-1 to Rattus_norvegicus_tRNA-Tyr-GTA-3-2